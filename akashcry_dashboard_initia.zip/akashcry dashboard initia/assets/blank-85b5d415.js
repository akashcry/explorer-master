import{d as o,r as n,h as e}from"./index-0bb3f38c.js";const a=o({setup(){const t=n("router-view");return()=>e("div",{class:"layout-wrapper layout-blank"},e(t))}});export{a as default};
