import{ag as e,o as c,m as n}from"./index-4807f7b2.js";const o={};function r(t,a){return c(),n("div",null,"NFT")}const _=e(o,[["render",r]]);export{_ as default};
