import{d as o,r as n,h as e}from"./index-4807f7b2.js";const a=o({setup(){const t=n("router-view");return()=>e("div",{class:"layout-wrapper layout-blank"},e(t))}});export{a as default};
