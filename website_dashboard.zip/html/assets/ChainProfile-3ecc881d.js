import{_ as f}from"./index-4807f7b2.js";export{f as default};
