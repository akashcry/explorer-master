import{ag as e,o as c,m as n}from"./index-3b4797b0.js";const o={};function r(t,a){return c(),n("div",null,"NFT")}const _=e(o,[["render",r]]);export{_ as default};
