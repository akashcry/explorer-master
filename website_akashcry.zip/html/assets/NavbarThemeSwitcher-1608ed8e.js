import{f}from"./index-3b4797b0.js";export{f as default};
